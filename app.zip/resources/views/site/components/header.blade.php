<div class="first_header">
    <div class="container">
        <div class="pull-left">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <div class="btn-group bootstrap-select">
                    {{--@if($lang == 'ar')--}}
                        {{--<a class="media-left header-link" href="{{url('/en')}}">English</a>--}}
                        {{--@else--}}
                        {{--<button type="button" class="btn dropdown-toggle btn-default" data-toggle="dropdown" role="button" title="English">--}}
                           {{--<a class="media-left header-link" href="{{url('/ar')}}">العربية</a>--}}
                        {{--</button>--}}
                        {{--@endif--}}

                        {{--<ul class="nav navbar-nav">--}}
                        {{--@if($lang == 'ar')--}}
                            {{--<li class="nav-item lang-link ">--}}
                                {{--<a class="media-left header-link" href="{{url('/en')}}">ENGLISH</a>--}}
                            {{--</li>--}}
                        {{--@else--}}
                            {{--<li class="nav-item lang-link ">--}}
                                {{--<a class="media-left header-link" href="{{url('/ar')}}">العربية</a>--}}
                            {{--</li>--}}
                        {{--@endif--}}
                    {{--</ul>--}}
                </div>
            </div>
        </div>
        <div class="pull-right">
            <div class="contact_details">
                <div class="media">
                    <div class="media-left">
                        <i class="mdi mdi-phone"></i>
                    </div>
                    <div class="media-body">

                        <h4>{{trim($config->main->site_phone)}}</h4>
                    </div>
                </div>
                <div class="media">
                    <div class="media-left">
                        <i class="mdi mdi-email"></i>
                    </div>
                    <div class="media-body">
                        <h4>{{trim($config->main->site_email)}}</h4>
                    </div>
                </div>
            </div>
            <ul class="header_social">
                @if(trim($config->social[1]['link']) != null)
                    <li><a href="{{$config->social[1]['link']}}" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                @endif
                    @if(trim($config->social[2]['link']) != null)
                        <li><a href="{{$config->social[2]['link']}}" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                    @endif
                    @if(trim($config->social[3]['link']) != null)
                        <li><a href="{{$config->social[3]['link']}}" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                    @endif
                    @if(trim($config->social[4]['link']) != null)
                    <li><a href="{{$config->social[4]['link']}}" target="_blank"><i class="mdi mdi-email-outline" aria-hidden="true"></i></a></li>
                    @endif
                    <li><a class="hide_icon" href="tel:{{$config->main->site_phone}}"> <i class="fa fa-phone"></i> </a></li>
            </ul>
        </div>
    </div>
</div>
<div class="main_menu_area menu_full_width">
    <nav class="navbar navbar-default">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#navbar" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                @if($lang=='ar')
                    <a class="navbar-brand" href="{{url($lang.'/')}}"><img src="{{$img}}/D_Logo.png" alt=""></a>
                @else
                    <a class="navbar-brand" href="{{url($lang.'/')}}"><img src="{{$img}}/D_Logo_EN_100px.png" alt=""></a>
                @endif
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="nav navbar-nav navbar-right">
                    <li class="@if(Request::segment(2) == '') active @endif" >
                        <a href="{{url('/'.$lang.'/')}}" class="">@lang('web.Home')</a>
                    </li>
                    <li class="@if(Request::segment(2) == 'sectors') active @endif">
                        <a href="{{url('/'.$lang.'/sectors')}}" class="">@lang('web.Sectors')</a>
                    </li>
                    <li class="@if(Request::segment(2) == 'news') active @endif">
                        <a href="{{url('/'.$lang.'/news')}}" class="">@lang('web.News')</a>
                    </li>
                    <li class="@if(Request::segment(2) == 'about') active @endif">
                        <a href="{{url('/'.$lang.'/about')}}">@lang('web.About')</a>
                    </li>
                    <li class="@if(Request::segment(2) == 'contact') active @endif">
                        <a href="{{url('/'.$lang.'/contact')}}">@lang('web.Contact')</a>
                    </li>

                    @if($lang == 'ar')
                        <li class="nav-item lang-link">
                            <a class="nav-link" href="{{url('/en')}}">English</a>
                        </li>
                    @else
                        <li class="nav-item lang-link">
                            <a class="nav-link" href="{{url('/ar')}}">العربية</a>
                        </li>
                    @endif

                </ul>
            </div>
        </div>
    </nav>
</div>

