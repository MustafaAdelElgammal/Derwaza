@extends('site.layout')
@section('meta')
    <title>{{$config->site_name}} | @lang('web.Sectors')</title>
    <meta name="description" content="{{$config->site_desc}}">
    <meta name="keywords" content="{{$config->site_keyword}}">
@endsection
@section('header_down')
    @include('site.components.banner')
@endsection
@section('content')
{{--<section class="service_details_area">--}}
    {{--<div class="container">--}}
        {{--<div class="row">--}}
            {{--<div class="col-md-9 pull-right">--}}
                {{--<div class="service_details_inner">--}}
                    {{--@foreach($sectors as $sector)--}}
                        {{--@php $sector = $sector->postByLang; @endphp--}}
                    {{--<div class="service_image_single">--}}
                        {{--<h3 class="h3-design">{{$sector->name}} </h3>--}}
                        {{--<img class="sectorimg" src="{{$up . '/posts/sectors/' . $sector->upload}}" alt="{{$sector->name}}">--}}
                        {{--<h5>{{$sector->other_inputs_values->brief}} </h5>--}}
                    {{--</div>--}}
                    {{--<div class="service_2column">--}}
                        {{--<div class="media">--}}
                            {{--@if($sector->other_inputs_values->secondary_img != null)--}}
                            {{--<div class="media-left">--}}
                                {{--<img src="{{$up . '/posts/sectors/' . $sector->other_inputs_values->secondary_img}}" alt="{{$sector->name}}">--}}
                            {{--</div>--}}
                            {{--@endif--}}
                            {{--<div class="media-body">--}}
                                {{--<h1>{!!$sector->short  !!}</h1>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                    {{--</div>--}}
                        {{--<div class="service_2column">--}}
                            {{--<div class="media">--}}
                                {{--<div class="media-left">--}}
                                {{--</div>--}}
                                {{--<div class="media-body">--}}
                                {{--</div>--}}
                            {{--</div>--}}
                        {{--</div>--}}

                    {{--@endforeach--}}
                {{--</div>--}}
            {{--</div>--}}
            {{--@include('site.components.sidebar')--}}
        {{--</div>--}}
    {{--</div>--}}
{{--</section>--}}
    @include('site.components.sectors')
<section class="why_chose_area">
    <div class="container">
        <div class="main_title">
            <h2><img class="left_img" src="{{$img}}/title-left-bar.png" alt="">Why choose us <img class="right_img" src="{{$img}}/title-right-bar.png" alt=""></h2>
            <p>There are many variations of passages</p>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="chose_item_inner">
                    <img src="{{$img}}/chose-icon/chose-icon-1.png" alt="">
                    <h4>Largest warehouse</h4>
                    <p>Integer congue, elit semper laoreet sed lectus orci posuh nisl tempor lacus felis ac mauris. elit </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="chose_item_inner">
                    <img src="{{$img}}/chose-icon/chose-icon-2.png" alt="">
                    <h4>logistic services</h4>
                    <p>Integer congue, elit semper laoreet sed lectus orci posuh nisl tempor lacus felis ac mauris. elit </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="chose_item_inner">
                    <img src="{{$img}}/chose-icon/chose-icon-3.png" alt="">
                    <h4>contract logistic</h4>
                    <p>Integer congue, elit semper laoreet sed lectus orci posuh nisl tempor lacus felis ac mauris. elit </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="chose_item_inner">
                    <img src="{{$img}}/chose-icon/chose-icon-4.png" alt="">
                    <h4>costumer support</h4>
                    <p>Integer congue, elit semper laoreet sed lectus orci posuh nisl tempor lacus felis ac mauris. elit </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="chose_item_inner">
                    <img src="{{$img}}/chose-icon/chose-icon-5.png" alt="">
                    <h4>largest destinations</h4>
                    <p>Integer congue, elit semper laoreet sed lectus orci posuh nisl tempor lacus felis ac mauris. elit </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="chose_item_inner">
                    <img src="{{$img}}/chose-icon/chose-icon-6.png" alt="">
                    <h4>goods tracking</h4>
                    <p>Integer congue, elit semper laoreet sed lectus orci posuh nisl tempor lacus felis ac mauris. elit </p>
                </div>
            </div>
        </div>
    </div>
</section>
{{--<div class="blog_zig_area">--}}
    {{--<div class="container">--}}
        {{--@foreach($sectors as $sector)--}}
            {{--@php $sector = $sector->postByLang; @endphp--}}
            {{--<div class="row">--}}
            {{--<div class="col-md-6">--}}
                {{--<div class="blog_zig_img_left">--}}
                    {{--<img src="{{$up . '/posts/sectors/' . $sector->upload}}" alt="{!! $sector->name !!}">--}}
                {{--</div>--}}
            {{--</div>--}}
            {{--<div class="col-md-6">--}}
                {{--<div class="blog_zig_content_left">--}}
                    {{--<h4>{!! $sector->name !!}</h4>--}}
                    {{--<p>{!! $sector->other_inputs_values->brief !!}</p>--}}
                    {{--<a class="readmore_btn balck_btn" href="#">Read more</a>--}}
                {{--</div>--}}
            {{--</div>--}}
        {{--</div>--}}
        {{--@endforeach--}}
        {{--<div class="row">--}}
            {{--<div class="col-md-6">--}}
                {{--<div class="blog_zig_content_right">--}}
                    {{--<h4>Have a Good Time</h4>--}}
                    {{--<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical </p>--}}
                    {{--<a class="readmore_btn balck_btn" href="#">Read more</a>--}}
                {{--</div>--}}
            {{--</div>--}}
            {{--<div class="col-md-6">--}}
                {{--<div class="blog_zig_img_right">--}}
                    {{--<img src="{{$img}}/blog/blog-zig/blog-zig-2.jpg" alt="">--}}
                {{--</div>--}}
            {{--</div>--}}
        {{--</div>--}}
    {{--</div>--}}
{{--</div>--}}
    @include('site.components.map')
@endsection
