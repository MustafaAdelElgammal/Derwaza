<!DOCTYPE html>
<!--[if lt IE 7 ]>
<html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]>
<html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]>
<html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    @yield('meta')
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#85c435">
    <link rel="shortcut icon" href="{{$img}}/D_Brand_Logo.png">
    {{ Html::style($css   . '/bootstrap.min.css') }}
    {{ Html::style($css   . '/main_en.css') }}
    @if($lang == 'ar')
         {{ Html::style($css   . '/bootstrap.rtl.min.css') }}
         {{ Html::style($css   . '/main_ar.css') }}
    @endif
    {{ Html::style($css   . '/skin-default.css') }}
    {{ Html::style($fonts . '/icofont/css/icofont.css') }}
    {{ Html::style($js    . '/owlcarousel2/assets/owl.carousel.min.css') }}
    {{ Html::style($js    . '/mb.YTPlayer/css/jquery.mb.YTPlayer.min.css') }}
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="wrapper">
    <div class="page-not-found">
        <div class="container">
            <div class="row" style="text-align: center;">

                <!-- Title Content Start -->
                <div class="col-sm-12 col-xs-12 commontop text-center" style="margin-top: 218px">
                    <img src="{{$img}}/D_Logo.png" alt="">

                    <h4 style="font-size: 90px">COMING SOON</h4>
                    <div class="divider style-1 center">
                        <img class="left_img" src="{{$img}}/title-right-bar.png" alt="">
                        <i class="icofont icofont-ui-press hr-icon"></i>
                        <img  class="left_img"  src="{{$img}}/title-left-bar.png" alt="">
                    </div>

                </div>
                <!-- Title Content End -->
            </div>
        </div>
    </div>
</div>
</body>
</html>
