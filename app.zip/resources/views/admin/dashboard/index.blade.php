@extends("admin.$layout")
@section('content')
    <div class="pageheader"><h2><i class="fa fa-home"></i> @lang('admin.dashboard')</h2></div>
    <div class="contentpanel"></div>
@endsection




