@extends("admin.$layout")
@section('content')
<div class="pageheader"><h2><i class="fa fa-heart"></i> @lang('admin.help')</h2></div>
<div class="contentpanel"></div>
@endsection