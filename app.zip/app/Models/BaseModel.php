<?php
namespace app\Models;
use Illuminate\Database\Eloquent\Model;
class BaseModel extends Model{
    public static $language ;
}
