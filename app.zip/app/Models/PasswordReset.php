<?php
namespace App\Models;
class PasswordReset extends BaseModel {}